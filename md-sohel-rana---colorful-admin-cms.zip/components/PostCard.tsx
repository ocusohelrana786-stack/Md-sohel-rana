
import React, { useState, useEffect } from 'react';
import { Heart, MessageCircle, Share2, Copy, Send, Phone, MessageSquare, Sparkles, ChevronDown, ChevronUp, ChevronRight, Tag, Trash2, ShieldAlert } from 'lucide-react';
import { Post, Comment, UserRole, User } from '../types';

interface PostCardProps {
  post: Post;
  onLike?: (id: string) => void;
  onComment?: (postId: string, text: string) => void;
  onDelete?: (id: string) => void; // Added for Admin control
}

const PostCard: React.FC<PostCardProps> = ({ post, onLike, onComment, onDelete }) => {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('current_user');
    if (saved) setCurrentUser(JSON.parse(saved));
  }, []);

  const isAdmin = currentUser?.role === UserRole.ADMIN || currentUser?.role === UserRole.MODERATOR;

  const handleCopy = () => {
    navigator.clipboard.writeText(post.content);
    alert('Copied to clipboard!');
  };

  const handleShare = (platform: string) => {
    const text = encodeURIComponent(post.content);
    if (platform === 'whatsapp') {
      window.open(`https://wa.me/?text=${text}`, '_blank');
    } else if (platform === 'messenger') {
      window.open(`fb-messenger://share/?link=${window.location.href}&app_id=123456789`, '_blank');
    } else if (platform === 'sms') {
      window.location.href = `sms:?body=${text}`;
    }
  };

  const isLongContent = post.content.length > 300;
  const displayContent = isLongContent && !isExpanded ? post.content.substring(0, 300) + "..." : post.content;

  const renderCategoryTag = () => {
    if (!post.category) return null;
    
    const parts = post.category.split(' | ');
    if (parts.length > 1) {
      return (
        <div className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-700 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-100 shadow-sm">
          <Tag size={12} className="opacity-60" />
          <span>{parts[0]}</span>
          <ChevronRight size={10} className="text-indigo-300" />
          <span>{parts[1]}</span>
        </div>
      );
    }

    return (
      <div className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-100 shadow-sm">
        <Tag size={12} className="opacity-60" />
        <span>{post.category}</span>
      </div>
    );
  };

  return (
    <div className="colorful-border mb-6 group relative">
      {/* Admin Quick Control Panel */}
      {isAdmin && (
        <div className="absolute top-6 right-6 z-40 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
           <div className="bg-indigo-900 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase flex items-center gap-2 shadow-2xl border border-indigo-700 backdrop-blur-md">
             <ShieldAlert size={14} /> Admin Mode
           </div>
           <button 
            onClick={() => {
               if(window.confirm('অ্যাডমিন হিসেবে আপনি কি এই পোস্টটি মুছে ফেলতে চান?')) {
                 if (onDelete) onDelete(post.id);
                 // Fallback for direct local deletion if no handler provided
                 const localPosts = JSON.parse(localStorage.getItem('user_local_posts') || '[]');
                 const updated = localPosts.filter((p: any) => p.id !== post.id);
                 localStorage.setItem('user_local_posts', JSON.stringify(updated));
                 window.location.reload(); // Quick way to refresh UI
               }
            }}
            className="p-3 bg-rose-600 text-white rounded-xl shadow-2xl hover:bg-rose-700 transition-all active:scale-90"
           >
             <Trash2 size={20} />
           </button>
        </div>
      )}

      <div className="bg-white rounded-[2.5rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500">
        {/* Story/Post Image Header */}
        {post.image && (
          <div className="relative h-72 md:h-96 w-full overflow-hidden">
            <img 
              src={post.image} 
              alt={post.title || 'Post Image'} 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
            <div className="absolute bottom-8 left-8 right-8">
               <div className="mb-4 inline-block drop-shadow-lg">
                 {renderCategoryTag()}
               </div>
              {post.title && <h2 className="text-3xl md:text-5xl font-black text-white drop-shadow-2xl leading-tight font-poppins">{post.title}</h2>}
            </div>
          </div>
        )}

        <div className="p-8 md:p-12 relative">
          {/* Floating Sticker */}
          {post.sticker && (
            <div className="absolute -top-10 right-10 text-6xl drop-shadow-2xl animate-pulse z-10">
              {post.sticker}
            </div>
          )}

          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-black text-xl shadow-xl border-2 border-white">
                {post.authorName[0].toUpperCase()}
              </div>
              <div>
                <h3 className="font-black text-gray-800 text-base">{post.authorName}</h3>
                <div className="flex items-center gap-2 text-gray-400 font-bold text-[10px] uppercase tracking-widest mt-0.5">
                  <Sparkles size={10} className="text-yellow-500" />
                  {new Date(post.timestamp).toLocaleString('bn-BD')}
                </div>
              </div>
            </div>
            {!post.image && renderCategoryTag()}
          </div>

          <div className={`text-gray-700 leading-[1.8] whitespace-pre-wrap transition-all duration-500 ${post.type === 'story' ? 'text-xl font-medium' : 'text-2xl font-black text-indigo-900 border-l-[6px] border-indigo-500 pl-8 py-4 bg-indigo-50/20 rounded-r-3xl'}`}>
            {displayContent}
            
            {isLongContent && (
              <button 
                onClick={() => setIsExpanded(!isExpanded)}
                className="block mt-6 text-indigo-600 font-black text-sm uppercase tracking-widest hover:underline flex items-center gap-2"
              >
                {isExpanded ? (
                  <>পড়া শেষ করুন <ChevronUp size={16} /></>
                ) : (
                  <>বাকিটুকু পড়ুন <ChevronDown size={16} /></>
                )}
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-6 pt-10 border-t border-gray-100 mt-10">
            <div className="flex items-center gap-3">
              <button 
                onClick={() => onLike && onLike(post.id)}
                className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white transition-all font-black text-sm shadow-sm"
              >
                <Heart size={20} className={post.likes > 0 ? 'fill-current' : ''} />
                <span>{post.likes}</span>
              </button>
              <button 
                onClick={() => setShowComments(!showComments)}
                className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white transition-all font-black text-sm shadow-sm"
              >
                <MessageCircle size={20} />
                <span>{post.comments.length}</span>
              </button>
            </div>

            <div className="flex items-center gap-3">
              <button onClick={handleCopy} className="p-4 bg-gray-50 hover:bg-indigo-600 hover:text-white text-gray-400 rounded-2xl transition-all shadow-sm" title="Copy Text">
                <Copy size={20} />
              </button>
              <button onClick={() => handleShare('whatsapp')} className="p-4 bg-green-50 hover:bg-green-600 hover:text-white text-green-600 rounded-2xl transition-all shadow-sm" title="Share on WhatsApp">
                <Send size={20} />
              </button>
              <button onClick={() => handleShare('sms')} className="p-4 bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-600 rounded-2xl transition-all shadow-sm" title="Send SMS">
                <Phone size={20} />
              </button>
              <button onClick={() => handleShare('messenger')} className="p-4 bg-blue-50 hover:bg-blue-600 hover:text-white text-blue-600 rounded-2xl transition-all shadow-sm" title="Share on Messenger">
                <MessageSquare size={20} />
              </button>
            </div>
          </div>

          {showComments && (
            <div className="mt-10 p-8 bg-gray-50 rounded-[2.5rem] border border-gray-100 animate-in slide-in-from-top-4 duration-300">
              <div className="space-y-6 mb-8 max-h-60 overflow-y-auto custom-scrollbar pr-4">
                {post.comments.map(c => (
                  <div key={c.id} className="flex gap-4 items-start">
                    <div className="w-10 h-10 rounded-xl bg-white shadow-sm flex items-center justify-center font-black text-indigo-600 border border-indigo-50">
                      {c.username[0].toUpperCase()}
                    </div>
                    <div className="flex-grow">
                      <div className="font-black text-indigo-800 text-sm mb-1">{c.username}</div>
                      <div className="text-gray-600 text-sm leading-relaxed">{c.text}</div>
                    </div>
                  </div>
                ))}
                {post.comments.length === 0 && (
                  <div className="text-gray-400 text-center font-bold italic py-4">প্রথম কমেন্টটি আপনিই করুন!</div>
                )}
              </div>
              <div className="flex gap-3">
                <input 
                  type="text" 
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="আপনার মন্তব্য লিখুন..." 
                  className="flex-grow px-6 py-4 rounded-2xl bg-white border border-gray-200 focus:ring-4 focus:ring-indigo-100 outline-none transition-all font-medium"
                />
                <button 
                  onClick={() => {
                    if (commentText.trim() && onComment) {
                      onComment(post.id, commentText);
                      setCommentText('');
                    }
                  }}
                  className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black hover:shadow-xl transition-all active:scale-95"
                >
                  Post
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PostCard;
