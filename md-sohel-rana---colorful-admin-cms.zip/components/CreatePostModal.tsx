
import React, { useState, useRef } from 'react';
import { X, Image as ImageIcon, Smile, Send, Sparkles, Tag, Type } from 'lucide-react';
import { Post, User } from '../types';
import { CATEGORIES } from '../constants';

interface CreatePostModalProps {
  user: User;
  onClose: () => void;
  onPostCreated: (post: Post) => void;
  defaultType: 'sms' | 'story';
  defaultCategory?: string;
}

const STICKERS = ['🔥', '❤️', '😂', '😍', '✨', '🙌', '😢', '💯', '🚀', '🌟', '🌹', '🦋', '🎈', '🎉', '👑', '💎', '📍', '✅', '⚡', '🌈'];

const CreatePostModal: React.FC<CreatePostModalProps> = ({ user, onClose, onPostCreated, defaultType, defaultCategory }) => {
  const [content, setContent] = useState('');
  const [title, setTitle] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [selectedSticker, setSelectedSticker] = useState<string | null>(null);
  const [category, setCategory] = useState(defaultCategory && defaultCategory !== 'সব' ? defaultCategory : 'সাধারণ');
  const [type, setType] = useState<'sms' | 'story'>(defaultType);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const availableCategories = type === 'sms' ? CATEGORIES.sms.filter(c => c !== 'সব') : CATEGORIES.story.filter(c => c !== 'সব');

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePost = () => {
    // Basic validation
    if (!content.trim()) return;
    
    // Required title for stories
    if (type === 'story' && !title.trim()) {
      alert('গল্প পোস্ট করার জন্য একটি শিরোনাম (Title) প্রয়োজন!');
      return;
    }

    const newPost: Post = {
      id: `user-post-${Date.now()}`,
      type: type,
      title: type === 'story' ? title.trim() : undefined,
      content: content.trim(),
      image: image || undefined,
      sticker: selectedSticker || undefined,
      authorId: user.id,
      authorName: user.username,
      timestamp: Date.now(),
      likes: 0,
      comments: [],
      category: category,
    };

    // Save to local storage for persistence across page loads
    const localPosts = JSON.parse(localStorage.getItem('user_local_posts') || '[]');
    localPosts.unshift(newPost);
    localStorage.setItem('user_local_posts', JSON.stringify(localPosts));

    onPostCreated(newPost);
    onClose();
  };

  const isPostDisabled = !content.trim() || (type === 'story' && !title.trim());

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-xl rounded-[3rem] shadow-2xl overflow-hidden border-4 border-indigo-50 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-6 border-b flex items-center justify-between bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-2xl flex items-center justify-center text-white backdrop-blur-md">
              <Sparkles size={20} />
            </div>
            <h2 className="text-xl font-black font-poppins">নতুন কন্টেন্ট তৈরি করুন</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto custom-scrollbar flex-grow space-y-6 bg-gray-50/50">
          {/* Type Toggle */}
          <div className="flex gap-2 p-1.5 bg-gray-200 rounded-[1.5rem] shadow-inner">
            <button 
              onClick={() => { setType('sms'); setCategory('সাধারণ'); }}
              className={`flex-1 py-3 rounded-2xl font-black text-sm transition-all ${type === 'sms' ? 'bg-white text-indigo-600 shadow-md scale-[1.02]' : 'text-gray-500 hover:text-gray-700'}`}
            >
              ক্যাপশন (SMS)
            </button>
            <button 
              onClick={() => { setType('story'); setCategory('সাধারণ'); }}
              className={`flex-1 py-3 rounded-2xl font-black text-sm transition-all ${type === 'story' ? 'bg-white text-indigo-600 shadow-md scale-[1.02]' : 'text-gray-500 hover:text-gray-700'}`}
            >
              গল্প (Story)
            </button>
          </div>

          {/* Category Selector */}
          <div className="space-y-3">
             <div className="flex items-center gap-2 px-2">
                <Tag size={16} className="text-indigo-500" />
                <span className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">ক্যাটাগরি</span>
             </div>
             <div className="flex flex-wrap gap-2">
                {availableCategories.map(cat => (
                  <button 
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className={`px-5 py-2.5 rounded-xl text-xs font-black border-2 transition-all ${category === cat ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'bg-white border-gray-100 text-gray-500 hover:border-indigo-200'}`}
                  >
                    {cat}
                  </button>
                ))}
             </div>
          </div>

          {/* Title Field (Only for Stories) */}
          {type === 'story' && (
            <div className="space-y-2 animate-in slide-in-from-top-4 duration-300">
              <label className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.2em] ml-2 flex items-center gap-2">
                <Type size={14} /> গল্পের শিরোনাম (প্রয়োজনীয়)
              </label>
              <input 
                type="text" 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="একটি আকর্ষণীয় শিরোনাম দিন..."
                className="w-full px-6 py-4 rounded-2xl bg-white border-2 border-gray-100 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-50 outline-none font-bold text-lg shadow-sm transition-all"
              />
            </div>
          )}

          {/* Content Textarea */}
          <div className="space-y-2 relative">
            <label className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.2em] ml-2">
              আপনার {type === 'sms' ? 'ক্যাপশন' : 'গল্পের মূল কথা'}
            </label>
            <div className="relative">
              <textarea 
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder={type === 'sms' ? 'কি ভাবছেন? সুন্দর একটি ক্যাপশন লিখুন...' : 'আপনার গল্পটি এখানে বিস্তারিতভাবে লিখুন...'}
                className="w-full h-48 p-8 rounded-[2.5rem] bg-white border-2 border-gray-100 focus:border-indigo-500 outline-none resize-none font-medium leading-relaxed shadow-sm text-lg"
              />
              {selectedSticker && (
                <div className="absolute bottom-6 right-6 text-6xl animate-bounce drop-shadow-2xl select-none z-10 pointer-events-none">
                  {selectedSticker}
                </div>
              )}
            </div>
          </div>

          {/* Sticker Selection */}
          <div className="space-y-3">
            <label className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.2em] ml-2 flex items-center gap-2">
              <Smile size={16} /> স্টিকার (Sticker যুক্ত করুন)
            </label>
            <div className="flex flex-wrap gap-2 p-5 bg-white rounded-[2.5rem] border-2 border-gray-100 shadow-inner">
              {STICKERS.map(s => (
                <button 
                  key={s}
                  onClick={() => setSelectedSticker(selectedSticker === s ? null : s)}
                  className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl transition-all active:scale-90 ${selectedSticker === s ? 'bg-indigo-600 scale-110 shadow-xl ring-4 ring-indigo-50' : 'bg-gray-50 hover:bg-gray-100 hover:scale-105'}`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Image Preview */}
          {image && (
            <div className="relative rounded-[2.5rem] overflow-hidden border-4 border-white shadow-2xl animate-in zoom-in duration-500 group">
              <img src={image} className="w-full h-64 object-cover" alt="Preview" />
              <button 
                onClick={() => setImage(null)}
                className="absolute top-4 right-4 p-3 bg-black/60 text-white rounded-full hover:bg-rose-500 transition-colors backdrop-blur-md"
              >
                <X size={20} />
              </button>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center gap-4">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 flex items-center justify-center gap-2 px-6 py-4 bg-emerald-500 text-white rounded-[1.5rem] font-black text-sm hover:bg-emerald-600 transition-all shadow-lg hover:-translate-y-1"
            >
              <ImageIcon size={20} />
              ফটো যুক্ত করুন (Photo)
            </button>
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageChange} />
          </div>
        </div>

        {/* Footer */}
        <div className="p-8 bg-white border-t flex gap-4">
          <button 
            onClick={onClose}
            className="px-6 py-4 text-gray-400 font-black hover:text-gray-600 transition-colors uppercase tracking-widest text-xs"
          >
            বাতিল
          </button>
          <button 
            onClick={handlePost}
            disabled={isPostDisabled}
            className={`flex-grow py-5 bg-indigo-600 text-white rounded-2xl font-black text-xl shadow-xl transition-all flex items-center justify-center gap-3 active:scale-95 border-b-8 border-indigo-900 ${isPostDisabled ? 'opacity-30 cursor-not-allowed border-none' : 'hover:-translate-y-1 hover:shadow-indigo-200'}`}
          >
            <Send size={24} />
            পোস্ট করুন
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreatePostModal;
