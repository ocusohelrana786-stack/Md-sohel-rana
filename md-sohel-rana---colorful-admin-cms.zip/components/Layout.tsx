

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Home, MessageSquare, BookOpen, Briefcase, GraduationCap, User, Settings, LogOut, Menu, X, PlusCircle, Layout as LayoutIcon } from 'lucide-react';
import Clock from './Clock';
// Removed non-existent Widget from types import
import { UserRole, DynamicPage, SiteConfig } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  user: any;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [siteConfig, setSiteConfig] = useState<SiteConfig>(() => {
    const saved = localStorage.getItem('site_config');
    return saved ? JSON.parse(saved) : {
      siteName: 'Md Sohel Rana',
      siteTagline: 'Professional Multi-functional Hub',
      footerText: 'Professional Content Management System.',
      themeGradient: 'from-indigo-600 via-purple-600 to-pink-600',
      showClock: true,
      enableAiSync: true,
      enableExamSystem: true,
      enableJobBoard: true
    };
  });
  
  const [dynamicPages, setDynamicPages] = useState<DynamicPage[]>(() => JSON.parse(localStorage.getItem('site_pages') || '[]'));

  const location = useLocation();

  useEffect(() => {
    const handleStorage = () => {
      const savedConfig = localStorage.getItem('site_config');
      if (savedConfig) setSiteConfig(JSON.parse(savedConfig));
      setDynamicPages(JSON.parse(localStorage.getItem('site_pages') || '[]'));
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  // Admin Code Injection Logic
  useEffect(() => {
    if (siteConfig.headerScripts) {
      const div = document.createElement('div');
      div.innerHTML = siteConfig.headerScripts;
      const scripts = div.querySelectorAll('script');
      scripts.forEach(s => {
        const newScript = document.createElement('script');
        if (s.src) newScript.src = s.src;
        else newScript.innerHTML = s.innerHTML;
        document.head.appendChild(newScript);
      });
    }
    if (siteConfig.footerScripts) {
      const div = document.createElement('div');
      div.innerHTML = siteConfig.footerScripts;
      const scripts = div.querySelectorAll('script');
      scripts.forEach(s => {
        const newScript = document.createElement('script');
        if (s.src) newScript.src = s.src;
        else newScript.innerHTML = s.innerHTML;
        document.body.appendChild(newScript);
      });
    }
  }, [siteConfig.headerScripts, siteConfig.footerScripts]);

  const navItems = [
    { name: 'Home', icon: Home, path: '/' },
    { name: 'SMS Zone', icon: MessageSquare, path: '/sms' },
    { name: 'Stories', icon: BookOpen, path: '/stories' },
    { name: 'BD Jobs', icon: Briefcase, path: '/jobs', hidden: !siteConfig.enableJobBoard },
    { name: 'Exam Prep', icon: GraduationCap, path: '/exam', hidden: !siteConfig.enableExamSystem },
  ];

  const isAdminOrMod = user && (user.role === UserRole.ADMIN || user.role === UserRole.MODERATOR);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className={`sticky top-0 z-50 bg-gradient-to-r ${siteConfig.themeGradient} text-white shadow-xl transition-all duration-500`}>
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 hover:bg-white/10 rounded-full transition-colors"
            >
              {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
            <Link to="/" className="flex flex-col group">
              <span className="text-2xl md:text-3xl font-black font-poppins tracking-tighter uppercase leading-none truncate max-w-[200px] md:max-w-none group-hover:scale-105 transition-transform origin-left">
                {siteConfig.siteName}
              </span>
              <span className="text-[10px] font-medium tracking-widest opacity-80 uppercase truncate max-w-[150px]">
                {siteConfig.siteTagline}
              </span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {navItems.filter(i => !i.hidden).map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold transition-all duration-300 ${
                  location.pathname === item.path 
                    ? 'bg-white text-indigo-700 shadow-xl' 
                    : 'hover:bg-white/20'
                }`}
              >
                <item.icon size={18} />
                <span>{item.name}</span>
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3 lg:gap-6">
            {siteConfig.showClock && (
              <div className="hidden sm:block">
                <Clock />
              </div>
            )}
            {user ? (
              <div className="flex items-center gap-2 lg:gap-4">
                <Link to="/profile" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
                  <div className="w-10 h-10 rounded-full border-2 border-white/50 overflow-hidden bg-white/20">
                    <img src={user.avatar || 'https://picsum.photos/seed/sohel/200'} alt="Avatar" className="w-full h-full object-cover" />
                  </div>
                </Link>
                {isAdminOrMod && (
                  <Link 
                    to="/admin" 
                    className="hidden lg:flex items-center gap-2 px-5 py-2.5 bg-yellow-400 text-indigo-900 rounded-full font-black hover:bg-yellow-300 transition-all shadow-lg hover:-translate-y-0.5"
                  >
                    <Settings size={18} />
                    <span>CPanel</span>
                  </Link>
                )}
                <button 
                  onClick={onLogout}
                  className="p-2.5 bg-white/10 hover:bg-rose-500 rounded-full transition-all group shadow-sm"
                  title="Logout"
                >
                  <LogOut size={20} className="group-hover:scale-110 transition-transform" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link to="/login" className="px-6 py-2.5 bg-white text-indigo-700 rounded-full font-black hover:bg-indigo-50 transition-all shadow-lg">Login</Link>
                <Link to="/register" className="hidden sm:block px-6 py-2.5 border-2 border-white/50 rounded-full font-black hover:bg-white/10 transition-all">Register</Link>
              </div>
            )}
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden bg-indigo-900 border-t border-indigo-700 p-6 space-y-4 shadow-2xl animate-in slide-in-from-top-4 duration-300">
            {navItems.filter(i => !i.hidden).map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsMenuOpen(false)}
                className="flex items-center gap-4 p-4 rounded-2xl text-xl font-black hover:bg-indigo-700 transition-colors"
              >
                <item.icon size={24} />
                {item.name}
              </Link>
            ))}
            {isAdminOrMod && (
               <Link
                to="/admin"
                onClick={() => setIsMenuOpen(false)}
                className="flex items-center gap-4 p-4 rounded-2xl text-xl font-black bg-yellow-400 text-indigo-900 hover:bg-yellow-300"
              >
                <Settings size={24} />
                Admin Panel
              </Link>
            )}
          </div>
        )}
      </header>

      <main className="flex-grow pb-12">
        {children}
      </main>

      <footer className="bg-slate-950 text-gray-400 py-16 text-center">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col items-center gap-8">
            <h2 className="text-3xl font-black text-white font-poppins tracking-tighter uppercase">{siteConfig.siteName}</h2>
            
            <div className="flex flex-wrap justify-center gap-x-8 gap-y-4 text-sm font-black uppercase tracking-widest">
              <Link to="/" className="hover:text-white transition-colors">Home</Link>
              {dynamicPages.map(page => (
                <Link key={page.id} to={`/page/${page.slug}`} className="hover:text-white transition-colors">
                  {page.title}
                </Link>
              ))}
              <Link to="/contact" className="hover:text-white transition-colors">Contact Us</Link>
            </div>

            <div className="w-20 h-1 bg-white/10 rounded-full"></div>

            <p className="text-[10px] opacity-40 max-w-lg leading-relaxed">
              &copy; {new Date().getFullYear()} {siteConfig.siteName}. {siteConfig.footerText}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
