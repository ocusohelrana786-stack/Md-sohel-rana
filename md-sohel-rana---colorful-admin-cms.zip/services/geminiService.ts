
import { GoogleGenAI, Type } from "@google/genai";

// AI Architect for Site Building commands
export const processAiArchitectCommand = async (command: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `You are the Master Architect for 'Md Sohel Rana CMS'. 
      Admin says: "${command}"
      Interpret this command to improve the website.
      If it's about adding a page, return a JSON object for a page.
      If it's about a feature, return its configuration.
      Format: JSON with 'action' (updateConfig|addPage|addPost), 'data' (object), and 'message' (Bengali explanation of what you did).`,
      config: {
        responseMimeType: "application/json",
      }
    });
    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Architect command failed", error);
    return { message: "AI Architect সংযোগ বিচ্ছিন্ন।" };
  }
};

export const generateSmsPosts = async (count: number = 10) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate ${count} professional Bengali captions/SMS.
      Categories: "আবেগ | ভালোবাসা", "জীবন | অনুপ্রেরণা", "বিনোদন | হাসি".
      Language: Bengali. Direct result as JSON array.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              content: { type: Type.STRING },
              category: { type: Type.STRING },
              author: { type: Type.STRING }
            }
          }
        }
      }
    });
    return JSON.parse(response.text || '[]');
  } catch (error) {
    return [];
  }
};

export const generateJobCirculars = async (page: number = 1) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate 10 CURRENT real-time job circulars for Bangladesh (Page ${page}). 
      Mix Govt/Private. Language: Bengali.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              company: { type: Type.STRING },
              position: { type: Type.STRING },
              deadline: { type: Type.STRING },
              location: { type: Type.STRING },
              link: { type: Type.STRING },
              type: { type: Type.STRING },
              industry: { type: Type.STRING }
            }
          }
        }
      }
    });
    return JSON.parse(response.text || '[]');
  } catch (error) {
    return [];
  }
};

export const generateStories = async (count: number = 3) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate ${count} fascinating Bengali stories. 
      Categories: "কল্পনা | ভৌতিক", "শিক্ষা | উপদেশমূলক".`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              content: { type: Type.STRING },
              category: { type: Type.STRING },
              author: { type: Type.STRING },
              imagePrompt: { type: Type.STRING }
            }
          }
        }
      }
    });
    return JSON.parse(response.text || '[]');
  } catch (error) {
    return [];
  }
};

export const generateMcqQuestions = async (category: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate 10 high-quality MCQ questions for '${category}' exam preparation in Bangladesh. 
      Include correctIndex (0-3) and a detailed 'explanation' in Bengali.
      Language: Bengali.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              question: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctIndex: { type: Type.INTEGER },
              explanation: { type: Type.STRING }
            },
            required: ['question', 'options', 'correctIndex', 'explanation']
          }
        }
      }
    });
    return JSON.parse(response.text || '[]');
  } catch (error) {
    return [];
  }
};

export const generateImage = async (prompt: string): Promise<string | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: `High-quality cinematic 16:9 illustration for a Bengali story: ${prompt}` }] },
      config: { imageConfig: { aspectRatio: "16:9" } },
    });
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
    return null;
  } catch (error) {
    return null;
  }
};
