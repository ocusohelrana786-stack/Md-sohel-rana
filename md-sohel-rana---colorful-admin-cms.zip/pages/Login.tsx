
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Lock, User as UserIcon, LogIn, AlertCircle, ShieldCheck, Sparkles } from 'lucide-react';
import { ADMIN_CREDENTIALS } from '../constants';
import { UserRole, User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Load master user list
    const savedUsers = JSON.parse(localStorage.getItem('registered_users') || '[]');

    // CHECK FOR ADMIN SPECIAL CASE
    if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
      const adminUser: User = {
        id: 'admin-primary',
        username: 'Admin',
        role: UserRole.ADMIN,
        avatar: 'https://picsum.photos/seed/sohel-admin/400',
        bio: 'Md Sohel Rana প্ল্যাটফর্মের মেইন অ্যাডমিন। সকল কিছু এখান থেকেই নিয়ন্ত্রিত হয়।',
        facebook: 'admin.sohel',
        whatsapp: '01700000000'
      };

      // Ensure Admin exists in the registered users list for Profile page searches
      const existingAdmin = savedUsers.find((u: User) => u.username.toLowerCase() === 'admin');
      if (!existingAdmin) {
        savedUsers.push(adminUser);
        localStorage.setItem('registered_users', JSON.stringify(savedUsers));
      }

      onLogin(adminUser);
      navigate('/admin'); // Admins go to CPanel by default
      return;
    }

    // Normal User Logic
    const user = savedUsers.find((u: any) => u.username.toLowerCase() === username.toLowerCase() && u.password === password);

    if (user) {
      onLogin(user);
      navigate('/');
    } else {
      setError('ইউজারনেম অথবা পাসওয়ার্ড সঠিক নয়। অ্যাডমিন হলে সঠিক আইডি দিন।');
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 bg-gray-50/50">
      <div className="bg-white p-10 md:p-16 rounded-[4rem] shadow-[0_35px_80px_-15px_rgba(0,0,0,0.1)] border border-gray-100 w-full max-w-lg relative overflow-hidden">
        {/* Animated Accent Bar */}
        <div className="absolute top-0 left-0 w-full h-3 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600"></div>
        
        <div className="text-center mb-12">
          <div className="w-28 h-28 bg-gradient-to-tr from-indigo-600 to-indigo-900 text-white rounded-[2.5rem] flex items-center justify-center mx-auto mb-8 shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-500">
            <LogIn size={56} />
          </div>
          <h1 className="text-4xl font-black text-gray-900 font-poppins tracking-tighter flex items-center justify-center gap-3">
            লগইন পোর্টাল <Sparkles size={24} className="text-yellow-400" />
          </h1>
          <p className="text-gray-500 font-bold mt-2 italic">আপনার প্রফেশনাল ড্যাশবোর্ডে স্বাগতম</p>
        </div>

        {error && (
          <div className="bg-rose-50 text-rose-600 p-6 rounded-3xl mb-10 flex items-center gap-4 border-2 border-rose-100 animate-in fade-in slide-in-from-top-4 duration-300">
            <AlertCircle size={28} />
            <span className="text-sm font-black leading-tight">{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="space-y-3">
            <label className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400 ml-3">আপনার ইউজারনেম</label>
            <div className="relative group">
              <UserIcon className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within:text-indigo-600 transition-colors" size={24} />
              <input 
                type="text" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                className="w-full pl-16 pr-8 py-6 rounded-[2rem] bg-gray-50 border-4 border-transparent focus:border-indigo-500 focus:bg-white outline-none transition-all font-black text-xl shadow-inner"
                placeholder="Username লিখুন"
              />
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400 ml-3">নিরাপদ পাসওয়ার্ড</label>
            <div className="relative group">
              <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within:text-indigo-600 transition-colors" size={24} />
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full pl-16 pr-8 py-6 rounded-[2rem] bg-gray-50 border-4 border-transparent focus:border-indigo-500 focus:bg-white outline-none transition-all font-black text-xl shadow-inner"
                placeholder="••••••••"
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full py-6 bg-gradient-to-r from-indigo-600 to-indigo-900 text-white rounded-[2.5rem] font-black text-2xl hover:shadow-[0_25px_50px_rgba(79,70,229,0.4)] hover:-translate-y-2 transition-all active:scale-95 flex items-center justify-center gap-4 border-b-8 border-indigo-950"
          >
            <span>প্রবেশ করুন</span>
            <ShieldCheck size={28} />
          </button>
        </form>

        <div className="mt-14 text-center">
          <p className="text-gray-400 font-bold">
            নতুন মেম্বার হতে চান? {' '}
            <Link to="/register" className="text-indigo-600 font-black hover:underline underline-offset-8">রেজিস্ট্রেশন করুন</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
