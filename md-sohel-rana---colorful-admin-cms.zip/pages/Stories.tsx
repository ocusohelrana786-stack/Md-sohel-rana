
import React, { useState, useEffect, useMemo } from 'react';
import { BookOpen, Search, RefreshCw, Sparkles, ChevronDown, PlusCircle, LayoutGrid, Zap, ImageIcon, Camera, Smile, Layers } from 'lucide-react';
import { generateStories, generateImage } from '../services/geminiService';
import PostCard from '../components/PostCard';
import CreatePostModal from '../components/CreatePostModal';
import { Post, User, Comment } from '../types';
import { OFFLINE_STORIES, CATEGORIES } from '../constants';

const Stories: React.FC = () => {
  const [stories, setStories] = useState<Post[]>([]);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [activeMainCategory, setActiveMainCategory] = useState('সব');
  const [activeSubCategory, setActiveSubCategory] = useState('সব');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('current_user');
    if (saved) setCurrentUser(JSON.parse(saved));
  }, []);

  // Parse Categories for Hierarchical UI
  const { mainCategories, subCategoriesMap } = useMemo(() => {
    const mains = new Set(['সব']);
    const subs: Record<string, string[]> = { 'সব': ['সব'] };

    CATEGORIES.story.forEach(cat => {
      if (cat === 'সব') return;
      const [main, sub] = cat.split(' | ');
      mains.add(main);
      if (!subs[main]) subs[main] = ['সব'];
      subs[main].push(sub);
    });

    return { mainCategories: Array.from(mains), subCategoriesMap: subs };
  }, []);

  const fetchStories = async (isInitial = false) => {
    if (isInitial) setInitialLoading(true);
    else setLoading(true);

    try {
      let aiPosts: Post[] = [];

      if (!isInitial || stories.length === 0) {
        const aiData = await generateStories(3);
        aiPosts = aiData.map((d: any, i: number) => ({
          id: `ai-story-${Date.now()}-${i}`,
          type: 'story',
          title: d.title,
          content: d.content,
          image: `https://images.unsplash.com/photo-1516414447565-b14be0adf13e?q=80&w=1000&auto=format&fit=crop`, 
          category: d.category,
          authorId: 'sys',
          authorName: d.author || 'সোহেল রানা AI',
          timestamp: Date.now(),
          likes: Math.floor(Math.random() * 100),
          comments: [],
          imagePrompt: d.imagePrompt 
        }));
      }

      if (isInitial) {
        const localStories: Post[] = JSON.parse(localStorage.getItem('user_local_posts') || '[]')
          .filter((p: Post) => p.type === 'story');

        const offlinePosts: Post[] = OFFLINE_STORIES.map((d, i) => ({
          id: `offline-story-${i}`,
          type: 'story',
          title: d.title,
          content: d.content,
          image: `https://picsum.photos/seed/story-${i}/1000/600`,
          category: d.category,
          authorId: 'sys',
          authorName: d.author,
          timestamp: Date.now() - (i * 3600000),
          likes: 500 + (i * 100),
          comments: [],
          imagePrompt: d.imagePrompt
        }));

        setStories([...localStories, ...aiPosts, ...offlinePosts]);
      } else {
        setStories(prev => [...prev, ...aiPosts]);
      }
      
      aiPosts.forEach(async (story) => {
        if (story.imagePrompt) {
          const aiImage = await generateImage(story.imagePrompt);
          if (aiImage) {
            setStories(current => current.map(p => 
              p.id === story.id ? { ...p, image: aiImage } : p
            ));
          }
        }
      });

    } catch (err) {
      console.error("Failed to fetch stories", err);
    } finally {
      setInitialLoading(false);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStories(true);
  }, []);

  const handleLike = (id: string) => {
    setStories(prev => prev.map(p => p.id === id ? { ...p, likes: p.likes + 1 } : p));
  };

  const handleComment = (postId: string, text: string) => {
    const newComment: Comment = {
      id: Date.now().toString(),
      userId: currentUser?.id || 'guest',
      username: currentUser?.username || 'ইউজার',
      text,
      timestamp: Date.now()
    };
    setStories(prev => prev.map(p => p.id === postId ? { ...p, comments: [...p.comments, newComment] } : p));
  };

  const onPostCreated = (newPost: Post) => {
    setStories([newPost, ...stories]);
  };

  const filteredStories = stories.filter(p => {
    if (activeMainCategory === 'সব') return true;
    if (!p.category) return false;
    
    const [pMain, pSub] = p.category.split(' | ');
    if (activeSubCategory === 'সব') return pMain === activeMainCategory;
    return pMain === activeMainCategory && pSub === activeSubCategory;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 pb-24">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12 bg-white p-10 rounded-[4rem] shadow-xl border border-blue-50 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 via-indigo-500 to-purple-600"></div>
        <div className="flex items-center gap-6">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-[2rem] flex items-center justify-center text-white shadow-xl rotate-12 transition-transform hover:rotate-0">
            <BookOpen size={40} />
          </div>
          <div>
            <h1 className="text-4xl font-black text-gray-900 font-poppins tracking-tighter uppercase">গল্পের মহাসাগর (Stories)</h1>
            <p className="text-gray-500 font-medium italic flex items-center gap-2">
              <Sparkles size={18} className="text-indigo-500" />
              আপনার জন্য বিশেষভাবে সংগৃহীত চমৎকার সব গল্প।
            </p>
          </div>
        </div>
        <button 
          onClick={() => fetchStories(false)}
          disabled={loading}
          className="p-5 bg-indigo-50 text-indigo-600 rounded-[1.5rem] font-black hover:bg-indigo-100 transition-all disabled:opacity-50 border border-indigo-100 shadow-sm active:scale-95"
        >
          <RefreshCw size={28} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Category Sidebar */}
        <aside className="lg:col-span-3 space-y-8">
          <div className="bg-white p-10 rounded-[3rem] shadow-xl border border-gray-100 sticky top-24 overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50/50 rounded-full -mr-16 -mt-16 group-hover:scale-110 transition-transform"></div>
            
            <h3 className="font-black text-gray-800 text-2xl mb-10 flex items-center gap-4 relative z-10">
              <LayoutGrid size={28} className="text-indigo-600" /> বিভাগসমূহ
            </h3>

            <div className="space-y-4 relative z-10">
              <div className="flex items-center gap-2 mb-4 px-2">
                 <Layers size={14} className="text-indigo-400" />
                 <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">প্রধান থিম</span>
              </div>
              
              <div className="flex flex-col gap-3">
                {mainCategories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => { setActiveMainCategory(cat); setActiveSubCategory('সব'); }}
                    className={`px-8 py-5 rounded-[1.5rem] text-left font-black transition-all text-sm border-2 ${
                      activeMainCategory === cat 
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xl translate-x-2' 
                        : 'text-gray-500 hover:bg-gray-50 border-transparent hover:border-gray-100'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {activeMainCategory !== 'সব' && subCategoriesMap[activeMainCategory] && (
                <div className="pt-8 mt-8 border-t border-gray-100 animate-in fade-in duration-500">
                  <div className="flex items-center gap-2 mb-6 px-2">
                     <Zap size={14} className="text-rose-400" />
                     <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">উপ-বিভাগ</span>
                  </div>
                  <div className="flex flex-col gap-2">
                    {subCategoriesMap[activeMainCategory].map(sub => (
                      <button
                        key={sub}
                        onClick={() => setActiveSubCategory(sub)}
                        className={`px-6 py-3 rounded-2xl text-left font-black text-xs transition-all ${
                          activeSubCategory === sub 
                            ? 'bg-rose-50 text-rose-600 border-2 border-rose-200 shadow-sm' 
                            : 'text-gray-400 hover:bg-gray-50'
                        }`}
                      >
                        • {sub}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </aside>

        {/* Stories Feed */}
        <section className="lg:col-span-9 space-y-12">
          {/* Post Box */}
          <div className="bg-white rounded-[4rem] p-10 shadow-2xl border border-gray-50 flex flex-col gap-8 group hover:-translate-y-1 transition-all">
            <div className="flex items-center gap-6">
              <div className="w-16 h-16 rounded-[1.5rem] overflow-hidden border-4 border-indigo-50 shadow-xl flex-shrink-0 transition-transform group-hover:rotate-6">
                 <img src={currentUser?.avatar || 'https://picsum.photos/seed/sohel/200'} className="w-full h-full object-cover" />
              </div>
              <button 
                onClick={() => {
                  if (currentUser) setShowCreateModal(true);
                  else alert('গল্প পোস্ট করতে প্রথমে লগইন করুন!');
                }}
                className="flex-grow bg-gray-50 hover:bg-gray-100 text-gray-400 font-black py-6 px-10 rounded-[2.5rem] text-left transition-all border border-gray-100 text-xl shadow-inner"
              >
                {activeMainCategory !== 'সব' ? `${activeMainCategory} > ${activeSubCategory !== 'সব' ? activeSubCategory : 'বিভাগ'} নিয়ে একটি বড় গল্প লিখুন...` : 'আপনার জীবনের চমৎকার কোনো গল্প শেয়ার করুন...'}
              </button>
            </div>
            <div className="flex items-center justify-around pt-6 border-t border-gray-50">
               <button onClick={() => setShowCreateModal(true)} className="flex items-center gap-3 text-gray-500 font-black hover:text-blue-600 hover:bg-blue-50 px-8 py-4 rounded-[1.5rem] transition-all">
                 <Camera className="text-blue-500" size={28} /> ফটো যুক্ত করুন
               </button>
               <button onClick={() => setShowCreateModal(true)} className="flex items-center gap-3 text-gray-500 font-black hover:text-emerald-600 hover:bg-emerald-50 px-8 py-4 rounded-[1.5rem] transition-all">
                 <PlusCircle className="text-emerald-500" size={28} /> নতুন গল্প লিখুন
               </button>
            </div>
          </div>

          {initialLoading && stories.length === 0 ? (
            <div className="space-y-12">
              {[1, 2].map(i => (
                <div key={i} className="bg-white rounded-[4rem] h-[600px] animate-pulse border border-gray-100 shadow-lg"></div>
              ))}
            </div>
          ) : (
            <div className="space-y-16">
              {filteredStories.map(story => (
                <PostCard key={story.id} post={story} onLike={handleLike} onComment={handleComment} />
              ))}
              
              {!loading && filteredStories.length > 0 && (
                <div className="flex flex-col items-center justify-center pt-12 gap-4">
                  <button 
                    onClick={() => fetchStories(false)}
                    className="group relative flex items-center gap-6 px-20 py-8 bg-white border-4 border-indigo-100 text-indigo-600 rounded-[3rem] font-black text-3xl shadow-2xl hover:shadow-indigo-300 hover:border-indigo-600 hover:-translate-y-3 transition-all disabled:opacity-50 overflow-hidden active:scale-95"
                  >
                    <div className="relative z-10 flex items-center gap-6">
                      <ChevronDown size={40} className="group-hover:translate-y-2 transition-transform" />
                      <span>আরও নতুন গল্প লোড করুন</span>
                    </div>
                    <div className="absolute inset-0 bg-indigo-50 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
                  </button>
                </div>
              )}

              {loading && (
                <div className="flex flex-col items-center py-20">
                   <div className="w-24 h-24 border-[10px] border-indigo-100 border-t-indigo-600 rounded-full animate-spin mb-6"></div>
                   <p className="text-indigo-600 text-xl font-black animate-pulse">এআই নতুন গল্প জেনারেট করছে...</p>
                </div>
              )}

              {filteredStories.length === 0 && !loading && (
                 <div className="text-center py-40 bg-white rounded-[5rem] border-8 border-dashed border-gray-100 group hover:border-indigo-100 transition-all">
                   <Sparkles className="mx-auto text-gray-200 mb-10 group-hover:text-indigo-200 transition-colors" size={100} />
                   <p className="text-gray-400 font-black text-3xl tracking-tighter">এই বিভাগে কোনো গল্প পাওয়া যায়নি।</p>
                   <button onClick={() => { setActiveMainCategory('সব'); setActiveSubCategory('সব'); }} className="mt-8 px-10 py-4 bg-indigo-600 text-white rounded-full font-black hover:bg-indigo-700 transition-colors shadow-xl">সবগুলো গল্প দেখুন</button>
                 </div>
              )}
            </div>
          )}
        </section>
      </div>

      {showCreateModal && currentUser && (
        <CreatePostModal 
          user={currentUser} 
          onClose={() => setShowCreateModal(false)} 
          onPostCreated={onPostCreated}
          defaultType="story"
          defaultCategory={activeMainCategory !== 'সব' ? `${activeMainCategory} | ${activeSubCategory !== 'সব' ? activeSubCategory : 'উপদেশমূলক'}` : 'কল্পনা | ভৌতিক'}
        />
      )}
    </div>
  );
};

export default Stories;
