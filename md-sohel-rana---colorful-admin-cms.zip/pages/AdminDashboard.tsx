
import React, { useState, useEffect } from 'react';
import { 
  Settings, Users, FileText, Palette, RefreshCw, BookOpen, Sparkles, Trash2, Edit, Check, X, Shield, Star, 
  BarChart3, MessageSquare, Type as TypeIcon, ToggleLeft, ToggleRight, Code2, Wrench, Layers, Bot, Terminal, Zap, Briefcase, PlusCircle
} from 'lucide-react';
import { generateSmsPosts, generateJobCirculars, generateStories, processAiArchitectCommand } from '../services/geminiService';
import { DynamicPage, User, UserRole, Post, SiteConfig } from '../types';
import { THEME_COLORS } from '../constants';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isAiWorking, setIsAiWorking] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  const [pages, setPages] = useState<DynamicPage[]>(() => JSON.parse(localStorage.getItem('site_pages') || '[]'));
  const [users, setUsers] = useState<User[]>(() => JSON.parse(localStorage.getItem('registered_users') || '[]'));
  const [allPosts, setAllPosts] = useState<Post[]>(() => JSON.parse(localStorage.getItem('user_local_posts') || '[]'));
  const [siteConfig, setSiteConfig] = useState<SiteConfig>(() => {
    const saved = localStorage.getItem('site_config');
    return saved ? JSON.parse(saved) : {
      siteName: 'Md Sohel Rana',
      siteTagline: 'Professional AI-Driven Hub',
      footerText: 'Professional Content Management System.',
      themeGradient: 'from-indigo-600 via-purple-600 to-pink-600',
      showClock: true,
      enableAiSync: true,
      enableExamSystem: true,
      enableJobBoard: true,
      activeFeatures: ['sms', 'story', 'jobs', 'exam']
    };
  });

  useEffect(() => {
    localStorage.setItem('site_pages', JSON.stringify(pages));
    localStorage.setItem('registered_users', JSON.stringify(users));
    localStorage.setItem('user_local_posts', JSON.stringify(allPosts));
    localStorage.setItem('site_config', JSON.stringify(siteConfig));
    window.dispatchEvent(new Event('storage'));
  }, [pages, users, allPosts, siteConfig]);

  const handleAiArchitect = async () => {
    if (!aiPrompt.trim()) return;
    setIsAiWorking(true);
    setSyncStatus("AI Architect সাইটের আর্কিটেকচার পরিবর্তন করছে...");
    
    try {
      const result = await processAiArchitectCommand(aiPrompt);
      if (result.action === 'addPage') {
        const newPage: DynamicPage = {
          id: `page-${Date.now()}`,
          title: result.data.title,
          slug: result.data.title.toLowerCase().replace(/ /g, '-'),
          content: result.data.content,
          status: 'published',
          createdAt: Date.now()
        };
        setPages(prev => [newPage, ...prev]);
      } else if (result.action === 'updateConfig') {
        setSiteConfig({ ...siteConfig, ...result.data });
      } else if (result.action === 'addPost') {
        const newPost: Post = { ...result.data, id: `ai-post-${Date.now()}`, timestamp: Date.now(), likes: 0, comments: [] };
        setAllPosts(prev => [newPost, ...prev]);
      }
      
      setSyncStatus(`সফল: ${result.message}`);
      setAiPrompt('');
      setTimeout(() => setSyncStatus(null), 5000);
    } catch (e) {
      alert("AI Command failed.");
    } finally {
      setIsAiWorking(false);
    }
  };

  const handleSyncAll = async (type: string) => {
    setIsAiWorking(true);
    setSyncStatus(`অনলাইন থেকে ${type} সংগ্রহ করা হচ্ছে...`);
    try {
      let results: any[] = [];
      if (type === 'sms') results = await generateSmsPosts(15);
      else if (type === 'job') results = await generateJobCirculars();
      else if (type === 'story') results = await generateStories(5);
      
      const newPosts: Post[] = results.map((r, i) => ({
        id: `ai-${type}-${Date.now()}-${i}`,
        type: type as any,
        title: r.title || (type === 'job' ? `${r.company} - ${r.position}` : undefined),
        content: r.content || `Location: ${r.location}\nDeadline: ${r.deadline}`,
        category: r.category || 'সাধারণ',
        authorId: 'ai',
        authorName: 'AI Manager',
        timestamp: Date.now(),
        likes: Math.floor(Math.random() * 50),
        comments: []
      }));

      const updated = [...newPosts, ...allPosts];
      setAllPosts(updated);
      localStorage.setItem('user_local_posts', JSON.stringify(updated));
      setSyncStatus(`সবগুলো পোস্ট সরাসরি লাইভ করা হয়েছে! ✅`);
    } catch (e) {
      alert("Sync failed.");
    } finally {
      setIsAiWorking(false);
      setTimeout(() => setSyncStatus(null), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      <aside className="w-full md:w-80 bg-slate-950 text-slate-400 p-6 space-y-8 flex flex-col h-screen md:sticky md:top-0">
        <div className="flex items-center gap-4 px-2 py-6">
          <div className="w-14 h-14 bg-gradient-to-tr from-indigo-500 to-indigo-800 rounded-2xl flex items-center justify-center text-white font-black shadow-lg shadow-indigo-500/20 rotate-3 transition-transform hover:rotate-0">SR</div>
          <div>
            <div className="text-white font-black text-lg uppercase tracking-tighter truncate w-40">{siteConfig.siteName}</div>
            <div className="text-[9px] font-bold text-indigo-400 flex items-center gap-1 uppercase tracking-widest"><Shield size={10} /> Professional CPanel</div>
          </div>
        </div>

        <nav className="space-y-1 flex-grow overflow-y-auto custom-scrollbar">
          {[
            { id: 'dashboard', name: 'Dashboard', icon: BarChart3 },
            { id: 'architect', name: 'AI Architect', icon: Bot },
            { id: 'pages', name: 'Live Pages', icon: Layers },
            { id: 'automation', name: 'Sync Hub', icon: RefreshCw },
            { id: 'users', name: 'Moderators', icon: Users },
            { id: 'appearance', name: 'Themes', icon: Palette },
            { id: 'settings', name: 'Global Settings', icon: Settings },
          ].map((item) => (
            <button 
              key={item.id} 
              onClick={() => setActiveTab(item.id)} 
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl font-black transition-all ${activeTab === item.id ? 'bg-indigo-600 text-white shadow-xl translate-x-1' : 'hover:bg-slate-900 hover:text-white'}`}
            >
              <item.icon size={20} /> <span className="text-sm">{item.name}</span>
            </button>
          ))}
        </nav>
      </aside>

      <main className="flex-grow p-6 md:p-12 overflow-y-auto relative bg-slate-50">
        <header className="mb-10 flex flex-col md:flex-row items-center justify-between gap-6 bg-white p-10 rounded-[3rem] shadow-sm border border-slate-100">
          <div>
            <h1 className="text-4xl font-black text-slate-900 uppercase tracking-tighter">{activeTab.replace('-', ' ')}</h1>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">Admin: Md Sohel Rana | System Level: MASTER</p>
          </div>
          {syncStatus && (
            <div className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs animate-pulse flex items-center gap-2">
              <Sparkles size={16} /> {syncStatus}
            </div>
          )}
        </header>

        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { label: 'Live Pages', val: pages.length, icon: FileText, bg: 'bg-blue-600' },
              { label: 'Community', val: users.length, icon: Users, bg: 'bg-indigo-600' },
              { label: 'Feed Content', val: allPosts.length, icon: MessageSquare, bg: 'bg-rose-600' },
              { label: 'AI Health', val: 'Active', icon: Bot, bg: 'bg-emerald-600' },
            ].map((s, i) => (
              <div key={i} className="bg-white p-10 rounded-[3rem] shadow-sm border border-slate-100 flex items-center gap-8 group hover:shadow-xl transition-all">
                <div className={`w-16 h-16 ${s.bg} rounded-3xl flex items-center justify-center text-white shadow-lg group-hover:rotate-6 transition-transform`}><s.icon size={32} /></div>
                <div>
                  <div className="text-4xl font-black text-slate-900 tracking-tighter">{s.val}</div>
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{s.label}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'architect' && (
          <div className="max-w-4xl space-y-10 animate-in slide-in-from-bottom-8 duration-500">
            <div className="bg-slate-900 p-12 md:p-16 rounded-[4rem] shadow-2xl border-[12px] border-slate-800 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/10 rounded-full -mr-32 -mt-32"></div>
               <h3 className="text-white text-4xl font-black mb-8 flex items-center gap-4"><Bot className="text-indigo-400" size={40} /> AI Site Architect</h3>
               <p className="text-slate-400 font-bold mb-10 text-lg">"অ্যাডমিন যা বলবে এআই সাইটের আর্কিটেকচার ঠিক সেভাবেই বদলে দিবে।"</p>
               
               <div className="relative group">
                  <Terminal className="absolute left-6 top-8 text-indigo-500" size={32} />
                  <textarea 
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    placeholder="যেমন: 'Create a new Contact Us page' অথবা 'Change theme to Rose'..."
                    className="w-full h-64 pl-20 pr-10 py-10 bg-slate-950 text-indigo-400 rounded-[3rem] font-mono text-xl border-4 border-slate-800 focus:border-indigo-600 outline-none transition-all shadow-inner"
                  />
               </div>
               
               <button 
                 onClick={handleAiArchitect}
                 disabled={isAiWorking}
                 className="w-full mt-10 py-8 bg-indigo-600 text-white rounded-[2.5rem] font-black text-2xl hover:shadow-[0_20px_40px_rgba(79,70,229,0.4)] transition-all flex items-center justify-center gap-5 active:scale-95 disabled:opacity-50"
               >
                 {isAiWorking ? <RefreshCw className="animate-spin" size={32} /> : <Zap size={32} />} 
                 এক্সিকিউট কমান্ড (EXECUTE AI)
               </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               {[
                 { title: 'New Service Page', cmd: 'Create a professional services page with dummy content' },
                 { title: 'Dark Mode Theme', cmd: 'Update site configuration to a dark indigo theme' },
                 { title: 'SEO Optimized Post', cmd: 'Generate an SEO optimized news post about career in BD' }
               ].map((q, i) => (
                 <button key={i} onClick={() => setAiPrompt(q.cmd)} className="bg-white p-8 rounded-[2.5rem] border-4 border-slate-100 hover:border-indigo-600 text-left font-black text-slate-700 transition-all text-sm group flex flex-col gap-3 shadow-sm">
                    <PlusCircle size={24} className="text-indigo-600 group-hover:rotate-90 transition-transform" />
                    {q.title}
                 </button>
               ))}
            </div>
          </div>
        )}

        {activeTab === 'automation' && (
           <div className="max-w-3xl space-y-8 animate-in fade-in duration-500">
             <div className="bg-white p-12 md:p-20 rounded-[4rem] shadow-xl border border-slate-100 flex flex-col items-center text-center">
                <div className="w-24 h-24 bg-indigo-50 text-indigo-600 rounded-[2rem] flex items-center justify-center mb-10 shadow-inner group relative">
                  <RefreshCw size={48} className={isAiWorking ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-700'} />
                </div>
                <h3 className="text-4xl font-black text-gray-900 mb-6 tracking-tighter uppercase">Direct Sync Automation</h3>
                <p className="text-gray-400 font-bold mb-12 leading-relaxed max-w-lg text-lg">অনলাইন ও অফলাইন ডাটাবেস থেকে সকল কন্টেন্ট সরাসরি মেইন ফিডে পাবলিশ করুন। ইউজারদের জন্য আনলিমিটেড কনটেন্ট নিশ্চিত করুন।</p>
                
                <div className="grid grid-cols-1 w-full gap-5">
                   <button onClick={() => handleSyncAll('sms')} className="py-7 bg-rose-600 text-white rounded-[2.5rem] font-black shadow-xl hover:-translate-y-2 transition-all flex items-center justify-center gap-4 text-xl"><MessageSquare size={28} /> Sync Social SMS Feed</button>
                   <button onClick={() => handleSyncAll('story')} className="py-7 bg-blue-600 text-white rounded-[2.5rem] font-black shadow-xl hover:-translate-y-2 transition-all flex items-center justify-center gap-4 text-xl"><BookOpen size={28} /> Sync Story Universe</button>
                   <button onClick={() => handleSyncAll('job')} className="py-7 bg-emerald-600 text-white rounded-[2.5rem] font-black shadow-xl hover:-translate-y-2 transition-all flex items-center justify-center gap-4 text-xl"><Briefcase size={28} /> Sync BD Job Circulars</button>
                </div>
             </div>
          </div>
        )}

        {/* pages tab simplified for integration */}
        {activeTab === 'pages' && (
          <div className="bg-white rounded-[4rem] overflow-hidden shadow-2xl border border-slate-100 animate-in slide-in-from-right-8 duration-500">
            <table className="w-full text-left">
              <thead className="bg-slate-50 font-black text-xs uppercase text-slate-400 tracking-[0.2em]">
                <tr><th className="px-12 py-10">Header / Title</th><th className="px-12 py-10">Slug / Route</th><th className="px-12 py-10 text-right">Control Center</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {pages.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-12 py-10 font-black text-gray-800 text-2xl group-hover:text-indigo-600 transition-colors">{p.title}</td>
                    <td className="px-12 py-10 font-mono text-sm text-indigo-400">/page/{p.slug}</td>
                    <td className="px-12 py-10 text-right">
                      <div className="flex justify-end gap-4">
                        <button className="p-4 text-indigo-600 bg-indigo-50 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all"><Edit size={24} /></button>
                        <button onClick={() => setPages(prev => prev.filter(pg => pg.id !== p.id))} className="p-4 text-rose-600 bg-rose-50 rounded-2xl hover:bg-rose-600 hover:text-white transition-all"><Trash2 size={24} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
