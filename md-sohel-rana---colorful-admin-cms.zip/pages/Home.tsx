
import React, { useState, useEffect } from 'react';
// Added missing BookOpen import from lucide-react
import { Sparkles, MessageSquare, Briefcase, GraduationCap, ArrowRight, Zap, CloudLightning, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';
import { generateSmsPosts, generateJobCirculars } from '../services/geminiService';
import { Post } from '../types';

const Home: React.FC = () => {
  const [stats, setStats] = useState({ posts: 0, jobs: 0, users: 1250 });

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden bg-indigo-950">
        <div className="absolute inset-0 opacity-30">
          <img src="https://picsum.photos/seed/tech/1920/1080" alt="Hero Bg" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-indigo-950/80 via-transparent to-indigo-950"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-500/20 border border-indigo-400/30 rounded-full text-indigo-300 text-sm font-bold mb-6 backdrop-blur-md">
            <Sparkles size={16} />
            <span>AI-Driven Professional Network</span>
          </div>
          <h1 className="text-5xl md:text-8xl font-black text-white font-poppins mb-6 tracking-tighter leading-tight">
            Elevate Your <span className="bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 to-orange-500">Professional</span> Journey
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-10 leading-relaxed font-light">
            Welcome to Md Sohel Rana - Your ultimate destination for real-time job news, 
            exclusive SMS captions, engaging stories, and top-tier job preparation tools. 
            Experience a truly modern and colorful web experience.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/register" className="w-full sm:w-auto px-10 py-5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-full font-bold text-lg hover:shadow-[0_0_30px_rgba(79,70,229,0.5)] transition-all">
              Join for Free
            </Link>
            <Link to="/exam" className="w-full sm:w-auto px-10 py-5 bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-full font-bold text-lg hover:bg-white/20 transition-all flex items-center justify-center gap-2">
              Start Exam Practice <ArrowRight size={20} />
            </Link>
          </div>
        </div>

        {/* Floating Decorative Elements */}
        <div className="absolute top-1/4 left-10 animate-bounce delay-1000 hidden lg:block">
           <Zap className="text-yellow-400 opacity-50" size={40} />
        </div>
        <div className="absolute bottom-1/4 right-10 animate-pulse hidden lg:block">
           <CloudLightning className="text-cyan-400 opacity-50" size={40} />
        </div>
      </section>

      {/* Feature Grid */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-black text-gray-900 mb-4 font-poppins">Explore Our Universe</h2>
          <div className="w-20 h-1.5 bg-indigo-600 mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { title: 'SMS Zone', desc: 'Copy-ready captions for Facebook, WhatsApp & Messenger.', icon: MessageSquare, color: 'bg-rose-500', link: '/sms' },
            { title: 'BD Job Feed', desc: 'Real-time automatic job circulars from all over Bangladesh.', icon: Briefcase, color: 'bg-emerald-500', link: '/jobs' },
            { title: 'Story Hub', desc: 'Engaging real-life and fictional stories to keep you entertained.', icon: BookOpen, color: 'bg-blue-500', link: '/stories' },
            { title: 'Exam Prep', desc: 'Practice with timed MCQ tests and track your performance.', icon: GraduationCap, color: 'bg-purple-500', link: '/exam' },
          ].map((item, i) => (
            <Link key={i} to={item.link} className="group bg-white p-8 rounded-3xl shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-2 transition-all duration-300 flex flex-col items-center text-center">
              <div className={`w-16 h-16 ${item.color} text-white rounded-2xl flex items-center justify-center mb-6 shadow-lg rotate-3 group-hover:rotate-0 transition-transform`}>
                <item.icon size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{item.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gradient-to-r from-indigo-900 to-indigo-800 py-16 text-white">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <div className="text-4xl font-black mb-1">50K+</div>
            <div className="text-indigo-300 text-sm font-medium uppercase tracking-widest">Active Users</div>
          </div>
          <div>
            <div className="text-4xl font-black mb-1">10K+</div>
            <div className="text-indigo-300 text-sm font-medium uppercase tracking-widest">Job Posts</div>
          </div>
          <div>
            <div className="text-4xl font-black mb-1">100K+</div>
            <div className="text-indigo-300 text-sm font-medium uppercase tracking-widest">SMS Captions</div>
          </div>
          <div>
            <div className="text-4xl font-black mb-1">5K+</div>
            <div className="text-indigo-300 text-sm font-medium uppercase tracking-widest">Success Stories</div>
          </div>
        </div>
      </section>

      {/* Featured Posts Placeholder */}
      <section className="max-w-7xl mx-auto px-4 pb-20">
        <div className="flex items-center justify-between mb-8">
           <h2 className="text-3xl font-black text-gray-900 font-poppins">Trending Now</h2>
           <Link to="/sms" className="text-indigo-600 font-bold flex items-center gap-1 hover:gap-2 transition-all">
             View All <ArrowRight size={18} />
           </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
           <div className="colorful-border">
             <div className="bg-white p-6 rounded-xl">
               <span className="text-xs font-bold text-rose-500 bg-rose-50 px-3 py-1 rounded-full mb-4 inline-block">TRENDING SMS</span>
               <p className="text-lg italic text-gray-700 font-medium leading-relaxed">"Success is not final, failure is not fatal: it is the courage to continue that counts."</p>
               <div className="mt-4 flex items-center justify-between border-t pt-4">
                 <div className="text-sm font-bold text-gray-500">- Winston Churchill</div>
                 <div className="flex gap-2">
                    <button className="p-2 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"><Sparkles size={16} /></button>
                 </div>
               </div>
             </div>
           </div>
           <div className="colorful-border">
             <div className="bg-white p-6 rounded-xl">
               <span className="text-xs font-bold text-emerald-500 bg-emerald-50 px-3 py-1 rounded-full mb-4 inline-block">LATEST JOB</span>
               <h3 className="text-xl font-bold text-gray-900 mb-1">Senior React Developer</h3>
               <p className="text-sm text-gray-500 mb-4">TechSolutions Ltd • Dhaka, BD</p>
               <div className="flex items-center justify-between border-t pt-4">
                 <div className="text-indigo-600 font-bold">৳ 85,000 - 120,000</div>
                 <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg font-bold text-sm">Apply Now</button>
               </div>
             </div>
           </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
