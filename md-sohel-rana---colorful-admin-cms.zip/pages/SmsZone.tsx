
import React, { useState, useEffect, useMemo } from 'react';
import { generateSmsPosts } from '../services/geminiService';
import PostCard from '../components/PostCard';
import CreatePostModal from '../components/CreatePostModal';
import { Post, Comment, User } from '../types';
import { MessageSquare, RefreshCw, Sparkles, PlusCircle, ImageIcon, Smile, Camera, ChevronRight, Layers, Zap } from 'lucide-react';
import { OFFLINE_SMS, CATEGORIES } from '../constants';

const SmsZone: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeMainCategory, setActiveMainCategory] = useState('সব');
  const [activeSubCategory, setActiveSubCategory] = useState('সব');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('current_user');
    if (saved) setCurrentUser(JSON.parse(saved));
  }, []);

  const { mainCategories, subCategoriesMap } = useMemo(() => {
    const mains = new Set(['সব']);
    const subs: Record<string, string[]> = { 'সব': ['সব'] };
    CATEGORIES.sms.forEach(cat => {
      if (cat === 'সব') return;
      const [main, sub] = cat.split(' | ');
      mains.add(main);
      if (!subs[main]) subs[main] = ['সব'];
      subs[main].push(sub);
    });
    return { mainCategories: Array.from(mains), subCategoriesMap: subs };
  }, []);

  const fetchPosts = async (isManual = false) => {
    setLoading(true);
    
    // 1. Get User Local Posts
    const localPosts: Post[] = JSON.parse(localStorage.getItem('user_local_posts') || '[]')
      .filter((p: Post) => p.type === 'sms');

    // 2. Format Offline Seed Data (Instant Load)
    const offlineFormatted: Post[] = OFFLINE_SMS.map((d, i) => ({
      id: `offline-sms-${i}`,
      type: 'sms',
      content: d.content,
      category: d.category,
      authorId: 'system',
      authorName: d.author,
      timestamp: Date.now() - (i * 3600000),
      likes: Math.floor(Math.random() * 200) + 50,
      comments: []
    }));

    // Start with offline + local for no waiting
    setPosts([...localPosts, ...offlineFormatted]);
    setLoading(false);

    // 3. Fetch AI supplement in background
    if (isManual || posts.length < 20) {
      const aiData = await generateSmsPosts(10);
      const aiFormatted: Post[] = aiData.map((d: any, i: number) => ({
        id: `ai-sms-${Date.now()}-${i}`,
        type: 'sms',
        content: d.content,
        category: d.category,
        authorId: 'ai',
        authorName: d.author || 'সোহেল রানা AI',
        timestamp: Date.now(),
        likes: 0,
        comments: []
      }));
      setPosts(prev => [...localPosts, ...aiFormatted, ...offlineFormatted]);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const handleLike = (id: string) => {
    setPosts(prev => prev.map(p => p.id === id ? { ...p, likes: p.likes + 1 } : p));
  };

  const handleComment = (postId: string, text: string) => {
    const newComment: Comment = {
      id: Date.now().toString(),
      userId: currentUser?.id || 'guest',
      username: currentUser?.username || 'ইউজার',
      text,
      timestamp: Date.now()
    };
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, comments: [...p.comments, newComment] } : p));
  };

  const onPostCreated = (newPost: Post) => {
    setPosts([newPost, ...posts]);
  };

  const filteredPosts = posts.filter(p => {
    if (activeMainCategory === 'সব') return true;
    if (!p.category) return false;
    const [pMain, pSub] = p.category.split(' | ');
    if (activeSubCategory === 'সব') return pMain === activeMainCategory;
    return pMain === activeMainCategory && pSub === activeSubCategory;
  });

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pb-32">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12 bg-white p-10 rounded-[3.5rem] shadow-xl border border-rose-50 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-rose-400 via-pink-500 to-indigo-600"></div>
        <div className="flex items-center gap-6">
          <div className="w-20 h-20 bg-gradient-to-br from-rose-500 to-pink-700 rounded-3xl flex items-center justify-center text-white shadow-xl rotate-3">
            <MessageSquare size={40} />
          </div>
          <div>
            <h1 className="text-4xl font-black text-gray-900 font-poppins tracking-tighter">SMS জোন Explorer</h1>
            <p className="text-gray-500 font-bold flex items-center gap-2">
              <Zap size={16} className="text-yellow-500" /> অফলাইন ও অনলাইন ডাটাবেস সিঙ্ক সক্রিয়।
            </p>
          </div>
        </div>
        <button 
          onClick={() => fetchPosts(true)}
          disabled={loading}
          className="p-5 bg-rose-50 text-rose-600 rounded-2xl font-black hover:bg-rose-100 transition-all shadow-sm border border-rose-100"
        >
          <RefreshCw size={32} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      <div className="bg-white rounded-[3rem] p-8 mb-10 shadow-xl border border-gray-100 flex flex-col gap-6">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 rounded-[1.5rem] overflow-hidden bg-indigo-50 border-4 border-white shadow-lg flex-shrink-0">
             <img src={currentUser?.avatar || 'https://picsum.photos/seed/user/200'} className="w-full h-full object-cover" />
          </div>
          <button 
            onClick={() => { if (currentUser) setShowCreateModal(true); else alert('লগইন করুন!'); }}
            className="flex-grow bg-gray-50 hover:bg-gray-100 text-gray-400 font-black py-6 px-10 rounded-[2.5rem] text-left transition-all border border-gray-100 shadow-inner text-xl"
          >
            আপনার মনের ক্যাপশনটি এখানে লিখুন...
          </button>
        </div>
      </div>

      {/* Categories UI */}
      <div className="flex flex-wrap gap-3 mb-10 bg-white p-6 rounded-[3rem] shadow-sm border border-gray-100">
        {mainCategories.map(cat => (
          <button
            key={cat}
            onClick={() => { setActiveMainCategory(cat); setActiveSubCategory('সব'); }}
            className={`px-8 py-4 rounded-[1.5rem] font-black transition-all text-sm border-2 ${
              activeMainCategory === cat ? 'bg-indigo-600 text-white border-indigo-600 shadow-xl' : 'bg-gray-50 text-gray-500 hover:border-gray-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="space-y-12">
        {filteredPosts.map(post => (
          <PostCard key={post.id} post={post} onLike={handleLike} onComment={handleComment} />
        ))}
      </div>

      {showCreateModal && currentUser && (
        <CreatePostModal 
          user={currentUser} 
          onClose={() => setShowCreateModal(false)} 
          onPostCreated={onPostCreated}
          defaultType="sms"
          defaultCategory={activeMainCategory !== 'সব' ? `${activeMainCategory} | ${activeSubCategory !== 'সব' ? activeSubCategory : 'সাধারণ'}` : 'আবেগ | ভালোবাসা'}
        />
      )}
    </div>
  );
};

export default SmsZone;
