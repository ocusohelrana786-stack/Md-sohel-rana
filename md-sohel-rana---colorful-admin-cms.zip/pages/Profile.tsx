
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Camera, Edit3, Save, MapPin, MessageCircle, Facebook, Send, Sparkles, ShieldCheck, Star, X } from 'lucide-react';
import { User, UserRole, Post } from '../types';

interface ProfileProps {
  user: User; 
  onUpdate: (user: User) => void;
}

const Profile: React.FC<ProfileProps> = ({ user: currentUser, onUpdate }) => {
  const { username } = useParams();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);
  
  const [profileUser, setProfileUser] = useState<User | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);

  const [formData, setFormData] = useState({
    username: '',
    bio: '',
    avatar: '',
    cover: '',
    facebook: '',
    whatsapp: '',
    location: 'ঢাকা, বাংলাদেশ'
  });

  useEffect(() => {
    const fetchProfile = () => {
      setLoading(true);
      const targetUsername = username || currentUser.username;
      const savedUsers = JSON.parse(localStorage.getItem('registered_users') || '[]');
      const found = savedUsers.find((u: User) => u.username.toLowerCase() === targetUsername.toLowerCase());
      
      if (found) {
        setProfileUser(found);
        setFormData({
          username: found.username,
          bio: found.bio || 'Md Sohel Rana প্ল্যাটফর্মের একজন গর্বিত সদস্য।',
          avatar: found.avatar || `https://picsum.photos/seed/${found.username}/400`,
          cover: found.cover || `https://picsum.photos/seed/bg-${found.username}/1200/600`,
          facebook: found.facebook || '',
          whatsapp: found.whatsapp || '',
          location: found.location || 'ঢাকা, বাংলাদেশ'
        });
      }
      setLoading(false);
    };
    fetchProfile();
  }, [username, currentUser]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'avatar' | 'cover') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setFormData(prev => ({ ...prev, [type]: reader.result as string }));
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    if (!profileUser) return;
    const updatedUser = { ...profileUser, ...formData };
    const savedUsers = JSON.parse(localStorage.getItem('registered_users') || '[]');
    const updatedList = savedUsers.map((u: User) => u.id === profileUser.id ? updatedUser : u);
    localStorage.setItem('registered_users', JSON.stringify(updatedList));
    if (profileUser.id === currentUser.id) onUpdate(updatedUser);
    setProfileUser(updatedUser);
    setIsEditing(false);
    alert('প্রোফাইল আপডেট হয়েছে! ✅');
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center font-black">প্রোফাইল লোড হচ্ছে...</div>;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <div className="relative h-64 md:h-96 w-full bg-slate-200 overflow-hidden">
        <img src={formData.cover} alt="Cover" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/30"></div>
        {isEditing && (
          <button onClick={() => coverInputRef.current?.click()} className="absolute bottom-6 right-6 p-4 bg-white/20 backdrop-blur-md text-white border-2 border-white/40 rounded-2xl font-black flex items-center gap-2">
            <Camera size={20} /> কভার পরিবর্তন
            <input type="file" ref={coverInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileChange(e, 'cover')} />
          </button>
        )}
      </div>

      <div className="max-w-7xl mx-auto px-4 relative -mt-24 md:-mt-32">
        <div className="flex flex-col md:flex-row items-center md:items-end gap-8 mb-12">
          <div className="relative">
            <div className="w-48 h-48 md:w-64 md:h-64 rounded-[3rem] border-[10px] border-white bg-white shadow-2xl overflow-hidden relative">
              <img src={formData.avatar} alt="Avatar" className="w-full h-full object-cover" />
              {isEditing && (
                <button onClick={() => fileInputRef.current?.click()} className="absolute inset-0 bg-black/60 flex items-center justify-center text-white cursor-pointer">
                  <Camera size={40} />
                  <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileChange(e, 'avatar')} />
                </button>
              )}
            </div>
            {profileUser?.role === UserRole.ADMIN && (
              <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-yellow-400 text-indigo-900 rounded-2xl flex items-center justify-center shadow-xl border-4 border-white"><ShieldCheck size={28} /></div>
            )}
          </div>

          <div className="flex-grow text-center md:text-left">
            <h1 className="text-4xl md:text-6xl font-black text-gray-900 tracking-tighter mb-2 flex items-center justify-center md:justify-start gap-3">
              {profileUser?.username}
              {profileUser?.role === UserRole.ADMIN && <Star className="text-yellow-500 fill-yellow-500" size={28} />}
            </h1>
            <p className="text-gray-400 font-bold flex items-center justify-center md:justify-start gap-1"><MapPin size={14} /> {formData.location}</p>
          </div>

          {profileUser?.id === currentUser.id && (
            <div className="flex gap-3">
              {isEditing ? (
                <button onClick={handleSave} className="px-10 py-5 bg-emerald-600 text-white rounded-2xl font-black shadow-lg flex items-center gap-2 transition-all"><Save size={20} /> সেভ করুন</button>
              ) : (
                <button onClick={() => setIsEditing(true)} className="px-10 py-5 bg-indigo-600 text-white rounded-2xl font-black shadow-lg flex items-center gap-2 transition-all"><Edit3 size={20} /> প্রোফাইল এডিট</button>
              )}
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4 space-y-8">
            <div className="bg-white p-10 rounded-[3rem] shadow-xl border border-gray-100">
              <h3 className="font-black text-xl flex items-center gap-2 text-gray-800 mb-6"><Sparkles className="text-indigo-600" /> বায়ো (Bio)</h3>
              {isEditing ? (
                <textarea value={formData.bio} onChange={(e) => setFormData({...formData, bio: e.target.value})} className="w-full p-5 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-indigo-600 outline-none font-medium h-32" />
              ) : (
                <p className="text-gray-600 font-bold italic">"{formData.bio}"</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
