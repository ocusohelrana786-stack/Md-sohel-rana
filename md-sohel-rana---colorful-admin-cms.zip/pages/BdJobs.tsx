
import React, { useState, useEffect } from 'react';
import { Briefcase, MapPin, Calendar, ExternalLink, RefreshCw, Bookmark, ChevronDown, Sparkles, Zap, Building2, Landmark } from 'lucide-react';
import { generateJobCirculars } from '../services/geminiService';
import { JobCircular } from '../types';

const BdJobs: React.FC = () => {
  const [jobs, setJobs] = useState<JobCircular[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [page, setPage] = useState(1);

  const fetchJobs = async (isLoadMore = false) => {
    if (isLoadMore) {
      setLoadingMore(true);
    } else {
      setLoading(true);
      setPage(1);
    }

    const nextPage = isLoadMore ? page + 1 : 1;
    const data = await generateJobCirculars(nextPage);
    
    if (isLoadMore) {
      setJobs(prev => [...prev, ...data]);
      setPage(nextPage);
    } else {
      setJobs(data);
    }
    
    setLoading(false);
    setLoadingMore(false);
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 pb-24">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12 bg-white p-8 rounded-[2.5rem] shadow-xl border border-emerald-50 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-400 via-teal-500 to-indigo-600"></div>
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-700 rounded-3xl flex items-center justify-center text-white shadow-xl -rotate-3 transition-transform hover:rotate-0">
            <Briefcase size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-gray-900 font-poppins uppercase">BD Jobs Central</h1>
            <p className="text-gray-500 font-medium flex items-center gap-1">
              <Sparkles size={14} className="text-emerald-500" /> 
              বাংলাদেশের সকল সরকারি ও বেসরকারি জবের নিউজ ফিড।
            </p>
          </div>
        </div>

        <button 
          onClick={() => fetchJobs()}
          disabled={loading}
          className="flex items-center gap-2 px-8 py-4 bg-emerald-600 text-white rounded-2xl font-black hover:shadow-[0_15px_30px_rgba(16,185,129,0.3)] hover:-translate-y-1 transition-all disabled:opacity-50 active:scale-95"
        >
          <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
          Refresh Feed
        </button>
      </div>

      {/* Content Grid */}
      {loading && page === 1 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="bg-white p-8 rounded-[2rem] h-64 animate-pulse border border-gray-100 shadow-sm">
              <div className="flex gap-4 mb-6">
                <div className="w-14 h-14 bg-gray-100 rounded-2xl"></div>
                <div className="space-y-3 flex-grow">
                  <div className="h-5 bg-gray-100 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-50 rounded w-1/2"></div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="h-4 bg-gray-50 rounded w-full"></div>
                <div className="h-4 bg-gray-50 rounded w-5/6"></div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
            {jobs.map((job, idx) => (
              <div key={`${job.id}-${idx}`} className="colorful-border group">
                <div className="bg-white rounded-[2.5rem] p-8 shadow-sm hover:shadow-2xl transition-all duration-500 flex flex-col h-full border border-gray-50 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50/50 rounded-bl-full -mr-16 -mt-16 transition-transform group-hover:scale-110"></div>
                  
                  <div className="flex justify-between items-start mb-6 relative z-10">
                    <div className={`w-16 h-16 rounded-2xl flex items-center justify-center font-black text-2xl shadow-inner border transition-all ${
                      job.type === 'Govt' 
                        ? 'bg-emerald-50 text-emerald-600 border-emerald-100' 
                        : 'bg-blue-50 text-blue-600 border-blue-100'
                    }`}>
                      {job.type === 'Govt' ? <Landmark size={28} /> : <Building2 size={28} />}
                    </div>
                    <div className="flex flex-col items-end gap-2">
                       <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-sm ${
                         job.type === 'Govt' 
                          ? 'bg-emerald-600 text-white' 
                          : 'bg-indigo-600 text-white'
                       }`}>
                         {job.type === 'Govt' ? 'GOVT JOB' : 'PRIVATE JOB'}
                       </span>
                       <button className="p-3 bg-gray-50 text-gray-300 hover:text-emerald-500 hover:bg-emerald-50 rounded-xl transition-all">
                         <Bookmark size={22} />
                       </button>
                    </div>
                  </div>
                  
                  <div className="relative z-10 mb-6">
                    <h3 className="text-2xl font-black text-gray-800 mb-2 group-hover:text-emerald-600 transition-colors leading-tight">{job.position}</h3>
                    <div className="flex items-center gap-2">
                      <div className="inline-flex items-center gap-2 text-emerald-600 font-black text-sm uppercase tracking-wider">
                        <Zap size={14} className="fill-emerald-600" />
                        {job.company}
                      </div>
                      <span className="text-gray-300">•</span>
                      <span className="text-gray-400 font-bold text-xs uppercase">{job.industry}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mb-8 flex-grow relative z-10">
                    <div className="flex items-center gap-3 text-gray-500 font-medium">
                      <div className="p-2 bg-gray-50 rounded-lg text-emerald-500">
                        <MapPin size={18} />
                      </div>
                      <span>{job.location}</span>
                    </div>
                    <div className="flex items-center gap-3 text-gray-500 font-medium">
                      <div className="p-2 bg-gray-50 rounded-lg text-rose-500">
                        <Calendar size={18} />
                      </div>
                      <span>আবেদনের শেষ সময়: <span className="text-gray-900 font-bold">{job.deadline}</span></span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-6 border-t border-gray-100 relative z-10">
                    <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                      Live Feed #{idx + 1}
                    </div>
                    <a 
                      href={job.link || '#'} 
                      target="_blank" 
                      rel="noreferrer"
                      className={`flex items-center gap-2 font-black rounded-xl px-6 py-3 transition-all text-sm ${
                        job.type === 'Govt' 
                          ? 'bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white' 
                          : 'bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white'
                      }`}
                    >
                      Apply Now <ExternalLink size={18} />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Next Page / Load More Button */}
          {jobs.length > 0 && (
            <div className="flex flex-col items-center justify-center pt-12 gap-4">
              <button 
                onClick={() => fetchJobs(true)}
                disabled={loadingMore}
                className="group relative px-12 py-6 bg-white border-4 border-emerald-100 text-emerald-600 rounded-[2.5rem] font-black text-2xl shadow-xl hover:shadow-emerald-200 hover:border-emerald-500 hover:-translate-y-2 transition-all disabled:opacity-50 overflow-hidden active:scale-95"
              >
                <div className="relative z-10 flex items-center gap-4">
                  {loadingMore ? (
                    <RefreshCw size={28} className="animate-spin" />
                  ) : (
                    <ChevronDown size={28} className="group-hover:translate-y-1 transition-transform" />
                  )}
                  <span>পরবর্তী পেজ লোড করুন</span>
                </div>
                <div className="absolute inset-0 bg-emerald-50 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
              </button>
              <p className="text-gray-400 font-bold text-sm italic">বর্তমানে {page} নম্বর পেজের জব ডাটা দেখানো হচ্ছে</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default BdJobs;
