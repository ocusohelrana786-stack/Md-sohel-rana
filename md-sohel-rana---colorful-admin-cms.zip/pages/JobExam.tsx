
import React, { useState, useEffect, useRef } from 'react';
import { GraduationCap, ChevronRight, CheckCircle2, Trophy, RefreshCw, Zap, BookOpen, Target, Award, XCircle, BrainCircuit, Clock as ClockIcon, ShieldCheck, School, Briefcase, Sparkles, AlertCircle } from 'lucide-react';
import { MCQQuestion } from '../types';
import { generateMcqQuestions } from '../services/geminiService';

const CATEGORIES = [
  { id: 'bcs', name: 'BCS & All Govt Jobs', icon: ShieldCheck, color: 'text-white', bg: 'bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600', fullWidth: true },
  { id: 'primary', name: 'প্রাইমারি শিক্ষক নিয়োগ', icon: School, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  { id: 'bank', name: 'ব্যাংক জব প্রস্তুতি', icon: Briefcase, color: 'text-blue-600', bg: 'bg-blue-50' },
  { id: 'ntrca', name: 'শিক্ষক নিবন্ধন (NTRCA)', icon: GraduationCap, color: 'text-rose-600', bg: 'bg-rose-50' }
];

const OFFLINE_DB: MCQQuestion[] = [
  { id: 'off-1', question: 'বাংলাদেশের সংবিধান কত তারিখে কার্যকর হয়?', options: ['১৬ ডিসেম্বর ১৯৭২', '১০ এপ্রিল ১৯৭২', '২৬ মার্চ ১৯৭২', '৭ মার্চ ১৯৭২'], correctIndex: 0, explanation: '১৯৭২ সালের ১৬ ডিসেম্বর থেকে বাংলাদেশের সংবিধান কার্যকর হয়।' },
  { id: 'off-2', question: 'মুজিবনগর সরকার কবে গঠিত হয়?', options: ['১০ এপ্রিল ১৯৭১', '১৭ এপ্রিল ১৯৭১', '২৬ মার্চ ১৯৭১', '৭ মার্চ ১৯৭১'], correctIndex: 0, explanation: '১৯৭১ সালের ১০ এপ্রিল মুজিবনগর সরকার গঠিত হয় এবং ১৭ এপ্রিল শপথ গ্রহণ করে।' },
  { id: 'off-3', question: 'পদ্মা সেতুর দৈর্ঘ্য কত কিলোমিটার?', options: ['৬.১৫ কিমি', '৫.১৫ কিমি', '৭.১৫ কিমি', '৬.৫০ কিমি'], correctIndex: 0, explanation: 'পদ্মা সেতুর মোট দৈর্ঘ্য ৬.১৫ কিলোমিটার।' },
  { id: 'off-4', question: 'চর্যাপদ কোন যুগে রচিত হয়?', options: ['প্রাচীন যুগ', 'মধ্য যুগ', 'আধুনিক যুগ', 'অন্ধকার যুগ'], correctIndex: 0, explanation: 'চর্যাপদ বাংলা সাহিত্যের প্রাচীন যুগের একমাত্র নিদর্শন।' },
  { id: 'off-5', question: 'রবীন্দ্রনাথ ঠাকুর কত সালে নোবেল পুরস্কার পান?', options: ['১৯১৩', '১৯১১', '১৯১৫', '১৯২১'], correctIndex: 0, explanation: '১৯১৩ সালে গীতাঞ্জলি কাব্যের জন্য তিনি নোবেল পান।' },
  { id: 'off-6', question: 'বাংলাদেশের রণসঙ্গীতের রচয়িতা কে?', options: ['কাজী নজরুল ইসলাম', 'রবীন্দ্রনাথ ঠাকুর', 'জসীম উদ্দীন', 'ডি.এল রায়'], correctIndex: 0, explanation: 'কাজী নজরুল ইসলামের চল চল চল গানটি বাংলাদেশের রণসঙ্গীত।' },
  { id: 'off-7', question: 'বাংলাদেশের একমাত্র প্রবাল দ্বীপ কোনটি?', options: ['সেন্টমার্টিন', 'কুতুবদিয়া', 'হাতিয়া', 'মহেশখালী'], correctIndex: 0, explanation: 'সেন্টমার্টিন হলো বাংলাদেশের একমাত্র প্রবাল দ্বীপ।' }
];

const JobExam: React.FC = () => {
  const [questions, setQuestions] = useState<MCQQuestion[]>(OFFLINE_DB);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [examStarted, setExamStarted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [category, setCategory] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);

  const fetchRef = useRef(false);

  // Auto-Sync Logic: Background fetching to ensure "Unlimited" MCQ
  const syncMoreQuestions = async (cat: string) => {
    if (isSyncing) return;
    setIsSyncing(true);
    try {
      const newBatch = await generateMcqQuestions(cat);
      if (newBatch && newBatch.length > 0) {
        setQuestions(prev => [...prev, ...newBatch]);
      }
    } catch (e) {
      console.warn("Background Sync Error", e);
    } finally {
      setIsSyncing(false);
    }
  };

  const startExam = (cat: string) => {
    setLoading(true);
    setCategory(cat);
    // Fast start using offline data
    setTimeout(() => {
      setExamStarted(true);
      setLoading(false);
      syncMoreQuestions(cat); // Start background sync immediately
    }, 400);
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      // Trigger background sync when near the end of current list
      if (questions.length - currentIndex < 5) {
        syncMoreQuestions(category);
      }
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
      setTimeLeft(60);
    } else {
      setIsFinished(true);
    }
  };

  const handleSelect = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);
    if (idx === questions[currentIndex].correctIndex) {
      setScore(prev => prev + 1);
    }
  };

  useEffect(() => {
    if (!examStarted || isFinished || isAnswered) return;
    if (timeLeft <= 0) {
      setIsAnswered(true);
      return;
    }
    const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, isAnswered, isFinished, examStarted]);

  if (!examStarted && !loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 mt-12 pb-24 animate-in fade-in duration-500">
        <div className="text-center mb-12">
          <div className="w-24 h-24 bg-gradient-to-tr from-indigo-600 to-indigo-900 text-white rounded-[2rem] flex items-center justify-center mx-auto mb-6 shadow-2xl animate-bounce">
            <GraduationCap size={48} />
          </div>
          <h1 className="text-4xl md:text-5xl font-black text-gray-900 mb-4 font-poppins tracking-tighter">Unlimited Job Prep MCQ</h1>
          <p className="text-gray-500 font-bold max-w-lg mx-auto leading-relaxed">অফলাইন ও অনলাইন ডাটাবেস থেকে হাজার হাজার প্রশ্ন। কোনো লোডিং টাইম ছাড়াই পরীক্ষা শুরু করুন।</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => startExam(cat.name)}
              className={`p-10 rounded-[3rem] border-4 border-transparent hover:border-indigo-500 hover:shadow-2xl transition-all text-left flex items-center gap-6 group ${cat.fullWidth ? `${cat.bg} text-white md:col-span-2` : 'bg-white shadow-sm'}`}
            >
              <div className={`p-4 rounded-2xl ${cat.fullWidth ? 'bg-white/20' : cat.bg} ${cat.fullWidth ? 'text-white' : cat.color} group-hover:scale-110 transition-transform`}>
                <cat.icon size={32} />
              </div>
              <div>
                <h3 className="text-2xl font-black">{cat.name}</h3>
                <p className="text-sm opacity-80 font-bold tracking-wide uppercase">Start Training Now</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh]">
        <div className="w-20 h-20 border-[8px] border-indigo-100 border-t-indigo-600 rounded-full animate-spin mb-6"></div>
        <h2 className="text-2xl font-black text-indigo-900 animate-pulse">প্রশ্নপত্র প্রস্তুত হচ্ছে...</h2>
      </div>
    );
  }

  if (isFinished) {
    return (
      <div className="max-w-2xl mx-auto px-4 mt-12 text-center pb-20">
        <div className="bg-white p-12 md:p-20 rounded-[4rem] shadow-2xl border-b-[16px] border-indigo-600 animate-in zoom-in duration-500">
          <Trophy size={100} className="mx-auto text-yellow-500 mb-8" />
          <h1 className="text-4xl font-black text-indigo-900 mb-4">অভিনন্দন!</h1>
          <p className="text-gray-500 font-bold mb-8">আপনার আজকের পারফরম্যান্স:</p>
          <div className="text-8xl font-black text-indigo-600 mb-10 tracking-tighter">{score} <span className="text-4xl text-gray-300">/ {questions.length}</span></div>
          <button onClick={() => window.location.reload()} className="w-full py-6 bg-indigo-600 text-white rounded-[2rem] font-black text-2xl flex items-center justify-center gap-4 hover:shadow-2xl transition-all active:scale-95">
            <RefreshCw /> নতুন করে শুরু করুন
          </button>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentIndex];
  if (!currentQ) return null;

  return (
    <div className="max-w-4xl mx-auto px-4 mt-12 pb-24 animate-in slide-in-from-bottom-8 duration-500">
      {/* Header Info */}
      <div className="bg-white p-8 rounded-[3rem] shadow-xl border border-indigo-50 flex items-center justify-between mb-8 relative overflow-hidden">
        {isSyncing && (
          <div className="absolute top-0 left-0 w-full h-1 bg-indigo-600 animate-shimmer overflow-hidden">
            <div className="w-full h-full bg-indigo-400 animate-pulse"></div>
          </div>
        )}
        <div className="flex items-center gap-5">
          <div className="w-14 h-14 bg-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-lg"><Zap size={28} /></div>
          <div>
            <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">প্রশ্ন নম্বর {currentIndex + 1}</div>
            <div className="text-xl font-black text-gray-900">{category}</div>
          </div>
        </div>
        <div className="flex items-center gap-4 bg-gray-50 px-6 py-4 rounded-3xl border border-gray-100">
          <ClockIcon size={28} className={timeLeft < 15 ? 'text-rose-500 animate-pulse' : 'text-indigo-600'} />
          <div className={`text-4xl font-black font-mono leading-none ${timeLeft < 15 ? 'text-rose-500' : 'text-indigo-900'}`}>{timeLeft}s</div>
        </div>
      </div>

      {/* MCQ Card */}
      <div className="bg-white rounded-[4rem] shadow-2xl relative overflow-hidden border border-slate-100 p-10 md:p-20">
        <h2 className="text-3xl md:text-4xl font-black text-gray-900 mb-16 leading-tight font-poppins">{currentQ.question}</h2>
        
        <div className="grid gap-5">
          {currentQ.options.map((opt, idx) => {
            const isCorrect = idx === currentQ.correctIndex;
            const isSelected = idx === selectedOption;
            let btnClass = "group w-full p-8 rounded-[2.5rem] text-left font-black text-xl border-4 transition-all flex justify-between items-center ";
            
            if (isAnswered) {
              if (isCorrect) btnClass += "border-emerald-500 bg-emerald-50 text-emerald-900";
              else if (isSelected) btnClass += "border-rose-500 bg-rose-50 text-rose-900";
              else btnClass += "border-gray-50 opacity-30";
            } else {
              btnClass += "border-gray-100 hover:border-indigo-500 hover:bg-indigo-50 text-gray-700 shadow-sm";
            }

            return (
              <button key={idx} disabled={isAnswered} onClick={() => handleSelect(idx)} className={btnClass}>
                <span className="flex-grow">{opt}</span>
                {isAnswered && isCorrect && <CheckCircle2 size={32} className="text-emerald-600 flex-shrink-0" />}
                {isAnswered && isSelected && !isCorrect && <XCircle size={32} className="text-rose-600 flex-shrink-0" />}
                {!isAnswered && (
                  <div className="w-8 h-8 rounded-full border-2 border-gray-200 group-hover:border-indigo-400 flex-shrink-0"></div>
                )}
              </button>
            );
          })}
        </div>

        {isAnswered && (
          <div className="mt-12 p-10 rounded-[3rem] bg-indigo-50 border-4 border-indigo-100 animate-in slide-in-from-bottom-8 duration-500">
            <div className="flex items-center gap-3 mb-4 text-indigo-900">
               <BrainCircuit size={32} />
               <h4 className="text-2xl font-black">বিস্তারিত ব্যাখ্যা:</h4>
            </div>
            <p className="text-gray-700 font-bold text-lg mb-10 leading-relaxed italic">"{currentQ.explanation}"</p>
            <button onClick={handleNext} className="w-full py-6 bg-indigo-600 text-white rounded-[2rem] font-black text-2xl flex items-center justify-center gap-4 hover:shadow-2xl transition-all group active:scale-95">
              পরবর্তী প্রশ্ন <ChevronRight className="group-hover:translate-x-2 transition-transform" />
            </button>
          </div>
        )}
      </div>

      <div className="mt-8 flex items-center justify-center gap-2 text-gray-400 font-black text-[10px] uppercase tracking-widest">
        <Sparkles size={14} className="text-indigo-400" /> AI Powered Endless Prep Mode Active
      </div>
    </div>
  );
};

export default JobExam;
